using Microsoft.AspNetCore.Mvc.RazorPages;

public class JenkinsModel : PageModel
{
    public void OnGet()
    {
    }
}
