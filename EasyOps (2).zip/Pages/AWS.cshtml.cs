using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EasyOps.Pages
{
    public class AwsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
